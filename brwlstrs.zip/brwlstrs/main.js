// main.js - Mapa estilo Brawl Stars CUADRADO GRANDE con JSON maps, hitbox simple, FPS, bloque AGUA SÓLIDO y PERSONAJE con transparencia INVERSA en hierba (sin brillo normal) en AthenaEnv PS2
const anchoPantalla = 640;
const altoPantalla = 448;

// Tamaño del mapa (CUADRADO: editable, se adapta automáticamente)
const map = {
    width: 2048,  // Cambia aquí para probar (ej: 500)
    height: 2048
};

// Márgenes para tierra (agua alrededor) - fijos, pero land se clampa si map pequeño
const margen = 300;

// Tierra central (verde, adaptada dinámicamente al tamaño del map)
const land = {
    x: margen,
    y: margen,
    width: Math.max(0, map.width - 2 * margen),
    height: Math.max(0, map.height - 2 * margen)
};

// Cargar imágenes de bloques
const bloqueImg = new Image("assets/bloque.png");  // Sólido con colisión
const hierbaImg = new Image("assets/hierba.png");  // Atravesable, sin colisión (arbusto)
const barrilImg = new Image("assets/barril.png");  // Sólido con colisión

// Imagen del personaje
const personajeImg = new Image("assets/personaje.png");

// Array de bloques cargados desde JSON
let bloques = [];

// Clase Bloque (con hitbox simple: solo ancho/alto)
class Bloque {
    constructor(data) {
        this.x = data.x || 0;
        this.y = data.y || 0;
        this.tipo = data.tipo || "bloque";
        // Ancho/alto para dibujar: de hitbox si existe, sino default 32 (o 40 para agua)
        this.ancho = data.hitbox ? (data.hitbox.ancho || 32) : (this.tipo === "agua" ? 40 : 32);
        this.alto = data.hitbox ? (data.hitbox.alto || 32) : (this.tipo === "agua" ? 40 : 32);
        this.solid = (this.tipo === "bloque" || this.tipo === "barril" || this.tipo === "agua");  // AGUA SÓLIDO con colisión
        this.hitbox = {
            xOffset: 0,  // Sin offsets
            yOffset: 0,
            ancho: data.hitbox ? (data.hitbox.ancho || 32) : (this.tipo === "agua" ? 40 : 32),
            alto: data.hitbox ? (data.hitbox.alto || 32) : (this.tipo === "agua" ? 40 : 32)
        };
        this.img = this.getImage();
    }

    getImage() {
        switch (this.tipo) {
            case "bloque": return bloqueImg;
            case "hierba": return hierbaImg;
            case "barril": return barrilImg;
            case "agua": return null;  // Sin imagen, usa fallback
            default: return null;
        }
    }

    draw(offsetX, offsetY) {
        const drawX = this.x + offsetX;
        const drawY = this.y + offsetY;
        if (this.img && this.img.ready()) {
            this.img.draw(drawX, drawY, this.ancho, this.alto);
        } else {
            // Fallback a rect coloreado por tipo (sin efecto raro: color fijo)
            let color = Color.new(128, 128, 128, 255);  // Gris default
            if (this.tipo === "hierba") color = Color.new(0, 255, 0, 255);  // Verde hierba
            else if (this.tipo === "barril") color = Color.new(139, 69, 19, 255);  // Marrón barril
            else if (this.tipo === "agua") color = Color.new(51, 153, 255, 255);  // Exacto mismo azul del mapa (fijo)
            Draw.rect(drawX, drawY, this.ancho, this.alto, color);
        }
    }

    colision(objeto) {  // colision con hitbox del bloque vs full objeto (ej: player)
        const blockHitX = this.x + this.hitbox.xOffset;
        const blockHitY = this.y + this.hitbox.yOffset;
        return (
            objeto.x < blockHitX + this.hitbox.ancho &&
            objeto.x + objeto.width > blockHitX &&
            objeto.y < blockHitY + this.hitbox.alto &&
            objeto.y + objeto.height > blockHitY
        );
    }
}

// Función para cargar mapa desde JSON (maneja hitbox simple)
function cargarMapa(nombreMapa) {
    const jsonFile = `host:/maps/${nombreMapa}.json`;
    try {
        const fileContent = std.open(jsonFile, "r");
        if (fileContent === null) {
            console.log(`Archivo ${jsonFile} no encontrado.`);
            return false;
        }
        const mapaData = JSON.parse(fileContent.readAsString().trim());
        fileContent.close();
        
        bloques = [];  // Limpia bloques previos

        if (mapaData.bloques && Array.isArray(mapaData.bloques)) {
            mapaData.bloques.forEach(b => {
                if (b.x !== undefined && b.y !== undefined && b.tipo) {
                    bloques.push(new Bloque(b));
                }
            });
        }

        console.log(`Mapa ${nombreMapa} cargado: ${bloques.length} bloques.`);
        return true;
    } catch (e) {
        console.log(`Error al cargar el mapa ${nombreMapa}.json: ${e.message}`);
        return false;
    }
}

// Jugador (con imagen personaje.png y transparencia INVERSA en hierba/arbusto)
const player = {
    img: personajeImg,
    x: land.width > 0 ? land.x + land.width / 2 - 32 : map.width / 2 - 32,  // Centro, asumiendo 64x64 img
    y: land.height > 0 ? land.y + land.height / 2 - 32 : map.height / 2 - 32,
    width: 64,  // Tamaño de la imagen (ajusta si es diferente)
    height: 64,
    speed: 5,  // Aceleración base
    velX: 0,
    velY: 0,
    friccion: 0.2,
    maxVel: 5,

    update() {
        // Acelera con D-Pad (mientras se sostiene)
        if (pad.pressed(Pads.LEFT)) this.velX -= this.speed;
        if (pad.pressed(Pads.RIGHT)) this.velX += this.speed;
        if (pad.pressed(Pads.UP)) this.velY -= this.speed;
        if (pad.pressed(Pads.DOWN)) this.velY += this.speed;

        // Aplica fricción
        this.velX *= (1 - this.friccion);
        this.velY *= (1 - this.friccion);
        if (Math.abs(this.velX) < 0.1) this.velX = 0;
        if (Math.abs(this.velY) < 0.1) this.velY = 0;

        // Limita velocidad máxima
        if (Math.abs(this.velX) > this.maxVel) this.velX = Math.sign(this.velX) * this.maxVel;
        if (Math.abs(this.velY) > this.maxVel) this.velY = Math.sign(this.velY) * this.maxVel;

        // Actualiza posición provisional
        let newX = this.x + this.velX;
        let newY = this.y + this.velY;

        // Chequea colisiones horizontales primero
        let collidingH = false;
        for (let bloque of bloques) {
            if (bloque.solid) {
                // Temp posición para check horizontal (y fijo)
                if (bloque.colision({x: newX, y: this.y, width: this.width, height: this.height})) {
                    collidingH = true;
                    if (this.velX > 0) newX = (bloque.x + bloque.hitbox.xOffset) - this.width;  // De derecha
                    else if (this.velX < 0) newX = (bloque.x + bloque.hitbox.xOffset) + bloque.hitbox.ancho;  // De izquierda
                    this.velX = 0;
                    break;
                }
            }
        }
        this.x = newX;

        // Chequea colisiones verticales (x actualizado)
        let collidingV = false;
        for (let bloque of bloques) {
            if (bloque.solid) {
                if (bloque.colision({x: this.x, y: newY, width: this.width, height: this.height})) {
                    collidingV = true;
                    if (this.velY > 0) newY = (bloque.y + bloque.hitbox.yOffset) - this.height;  // De abajo
                    else if (this.velY < 0) newY = (bloque.y + bloque.hitbox.yOffset) + bloque.hitbox.alto;  // De arriba
                    this.velY = 0;
                    break;
                }
            }
        }
        this.y = newY;

        // Efecto de transparencia INVERSO en hierba/arbusto (transparente EN arbusto, normal FUERA sin brillo)
        let enArbusto = false;
        for (let bloque of bloques) {
            if (bloque.tipo === "hierba" && bloque.colision({x: this.x, y: this.y, width: this.width, height: this.height})) {
                enArbusto = true;
                break;
            }
        }
        if (enArbusto) {
            this.img.color = Color.new(128, 128, 128, 50);  // Tint gris con opacidad 50% EN arbusto (transparente)
        } else {
            this.img.color = Color.new(128, 128, 128);  // Blanco full opaco FUERA (sin tint, elimina brillo por default alpha)
        }

        // LÍMITES SOLO EN LA TIERRA VERDE! (no puede ir al agua; adaptado a land size)
        if (land.width > 0) {
            if (this.x < land.x) this.x = land.x;
            if (this.y < land.y) this.y = land.y;
            if (this.x + this.width > land.x + land.width) this.x = land.x + land.width - this.width;
            if (this.y + this.height > land.y + land.height) this.y = land.y + land.height - this.height;
        } else {
            // Si no hay land (map muy pequeño), limita al map full
            if (this.x < 0) this.x = 0;
            if (this.y < 0) this.y = 0;
            if (this.x + this.width > map.width) this.x = map.width - this.width;
            if (this.y + this.height > map.height) this.y = map.height - this.height;
        }
    },

    draw(offsetX, offsetY) {
        // Dibuja la imagen del personaje en coordenadas de pantalla (world + offset)
        const drawX = this.x + offsetX;
        const drawY = this.y + offsetY;
        if (this.img.ready()) {
            this.img.draw(drawX, drawY, this.width, this.height);
        } else {
            // Fallback a rect rojo si imagen no carga
            Draw.rect(drawX, drawY, this.width, this.height, Color.new(255, 0, 0, 255));
        }
    }
};

// Cámara (sigue al jugador, centrada, clamped al mapa - adaptada para tamaños pequeños)
const camera = {
    x: 0,
    y: 0,
    width: anchoPantalla,
    height: altoPantalla,

    update() {
        // Posición ideal centrada en jugador
        let targetX = player.x + player.width / 2 - this.width / 2;
        let targetY = player.y + player.height / 2 - this.height / 2;

        // Clamp para que la cámara no salga del mapa (si map pequeño, fija en 0)
        this.x = Math.max(0, Math.min(targetX, Math.max(0, map.width - this.width)));
        this.y = Math.max(0, Math.min(targetY, Math.max(0, map.height - this.height)));
    }
};

const pad = Pads.get(0);
const font = new Font("default");

// Carga módulo de pads
IOP.loadDefaultModule(IOP.pads);

Screen.setVSync(true);  // FPS estables

// Carga el mapa al inicio (ej: mapa1.json)
cargarMapa("mapa1");  // Cambia por el nombre de tu JSON

while (true) {
    pad.update();
    Screen.clear();

    player.update();
    camera.update();

    // Offset de cámara (negativo para dibujar mundo en screen)
    const offsetX = -camera.x;
    const offsetY = -camera.y;

    // COLOR AGUA EXACTO
    const colorAgua = Color.new(51, 153, 255, 255);

    // Dibuja agua FIJA full screen (siempre cubre, sin bugs en tamaños pequeños)
    Draw.rect(0, 0, anchoPantalla, altoPantalla, colorAgua);

    // Dibuja tierra (verde, superpuesto con offset - solo si land existe y cubre su área visible)
    if (land.width > 0 && land.height > 0) {
        const landDrawX = land.x + offsetX;
        const landDrawY = land.y + offsetY;
        const landDrawW = land.width;
        const landDrawH = land.height;
        // Clip si land fuera de screen (evita overdraw innecesario)
        if (landDrawX < anchoPantalla && landDrawY < altoPantalla && landDrawX + landDrawW > 0 && landDrawY + landDrawH > 0) {
            Draw.rect(landDrawX, landDrawY, landDrawW, landDrawH, Color.new(0, 100, 0, 255));
        }
    }

    // Dibuja todos los bloques (con offset)
    for (let bloque of bloques) {
        bloque.draw(offsetX, offsetY);
    }

    // Dibuja jugador CON offset
    player.draw(offsetX, offsetY);

    // Debug info + FPS + tamaños para test
    font.print(15, 30, `CAMARA: X ${Math.round(camera.x)} | Y: ${Math.round(camera.y)}`);
    font.print(15, 55, `JUGADOR: X ${Math.round(player.x)} | Y: ${Math.round(player.y)}`);
    font.print(15, 80, `BLOQUES: ${bloques.length}`);
    font.print(30, 105, `FPS: ${Screen.getFPS(360)}`);
    font.print(15, 130, `MAP: ${map.width}x${map.height} | LAND: ${land.width}x${land.height}`);

    Screen.flip();
}