// ============================================================================
//  FORTNITE - Battle Royale para PS2 (Athena Engine)
// ============================================================================
// Vista tercera persona, sistema de construccion, pico, armas, tormenta,
// HUD completo estilo Fortnite (escudo, vida, inventario, minimapa, brujula)
// ============================================================================

const font = new Font("default");
font.scale = 0.7;

Screen.setFrameCounter(true);
Screen.setVSync(true);

const canvas = Screen.getMode();
canvas.zbuffering = true;
canvas.psmz = Screen.Z16S;
Screen.setMode(canvas);

Render.init();
Render.setView(70.0, 0.5, 300.0);

// ============================================================================
//  LOAD MODELS
// ============================================================================

// Player character
os.chdir("chter");
const playerMesh = new RenderData("scene.gltf");
playerMesh.face_culling = Render.CULL_FACE_NONE;
playerMesh.pipeline = Render.PL_DEFAULT;
os.chdir("..");

// Ground (flat map)
const groundMesh = new RenderData("ground.obj");
groundMesh.face_culling = Render.CULL_FACE_NONE;
groundMesh.pipeline = Render.PL_DEFAULT;

// Cube (for building pieces)
const cubeMesh = new RenderData("cube.obj");
cubeMesh.face_culling = Render.CULL_FACE_NONE;
cubeMesh.pipeline = Render.PL_DEFAULT;

// Enemy model
const enemyMesh = new RenderData("enemy.obj");
enemyMesh.face_culling = Render.CULL_FACE_NONE;
enemyMesh.pipeline = Render.PL_DEFAULT;

// ============================================================================
//  CREATE RENDER OBJECTS
// ============================================================================
const groundObj = new RenderObject(groundMesh);
groundObj.scale = { x: 3.0, y: 3.0, z: 3.0 }; // Mapa mas grande

const playerModel = new RenderObject(playerMesh);
playerModel.scale = { x: 0.6, y: 0.6, z: 0.6 };

// Build preview ghost piece (reusable)
const previewObj = new RenderObject(cubeMesh);
previewObj.scale = { x: 3.0, y: 3.0, z: 0.2 };

// ============================================================================
//  LIGHTING
// ============================================================================
const light0 = Lights.new();
Lights.set(light0, Lights.DIRECTION, 0.3, 1.0, 0.5);
Lights.set(light0, Lights.AMBIENT, 0.55, 0.50, 0.45);
Lights.set(light0, Lights.DIFFUSE, 1.3, 1.1, 0.8); // Sunset warm light

// ============================================================================
//  COLORS
// ============================================================================
const white = Color.new(255, 255, 255);
const black = Color.new(0, 0, 0);
const red = Color.new(255, 50, 50);
const green = Color.new(50, 255, 50);
const yellow = Color.new(255, 255, 50);
const blue = Color.new(50, 100, 255);
const cyan = Color.new(50, 200, 255);
const orange = Color.new(255, 150, 50);
const gray = Color.new(120, 120, 120);
const darkGray = Color.new(40, 40, 40);
const semiBlack = Color.new(0, 0, 0, 80);
const semiBlack2 = Color.new(0, 0, 0, 120);
const goldColor = Color.new(255, 215, 0);
const grayText = Color.new(180, 180, 180);
const dmgColorNormal = Color.new(255, 200, 50);
const dmgColorCrit = Color.new(255, 50, 50);

// Fortnite specific colors
const shieldColor = Color.new(50, 130, 255);
const shieldBg = Color.new(20, 50, 100);
const healthColor = Color.new(50, 220, 80);
const healthBg = Color.new(20, 60, 20);
const stormColor = Color.new(100, 50, 200, 60);
const buildWood = Color.new(160, 110, 50);
const buildStone = Color.new(150, 150, 150);
const buildMetal = Color.new(100, 120, 160);
const buildPreview = Color.new(80, 150, 255, 80);
const slotBg = Color.new(30, 30, 40, 180);
const slotSelected = Color.new(255, 255, 255, 200);
const slotBorder = Color.new(80, 80, 100);
const compassBg = Color.new(0, 0, 0, 100);
const minimapBg = Color.new(0, 0, 0, 90);
const minimapBorder = Color.new(80, 80, 80);
const stormMinimap = Color.new(150, 80, 255, 100);
const muzzleC = Color.new(255, 200, 50, 120);
const buildHighlight = Color.new(50, 120, 200, 80);
const controlsColor = Color.new(150, 150, 150);
const skyColor = Color.new(180, 120, 60, 128);

// ============================================================================
//  PLAYER STATE
// ============================================================================
let playerX = 0.0;
let playerY = 1.8;
let playerZ = 5.0;
let yaw = 0.0;
let pitch = 0.0;
let playerYaw = 0.0;

let health = 100;
let shield = 50;
const maxHealth = 100;
const maxShield = 100;

let velocityY = 0.0;
let isOnGround = true;
let currentFOV = 70.0;
let isAiming = false;

// Materials
let woodCount = 300;
let stoneCount = 150;
let metalCount = 50;

// ============================================================================
//  INVENTORY SYSTEM (Fortnite slots)
// ============================================================================
// Slot 0 = Pico (siempre), Slots 1-4 = armas/items
const inventory = [
    { name: "PICO", type: "pickaxe", ammo: -1, maxAmmo: -1, damage: 20, icon: "P" },
    { name: "ESCOPETA", type: "shotgun", ammo: 8, maxAmmo: 8, damage: 80, icon: "S" },
    { name: "RIFLE", type: "rifle", ammo: 30, maxAmmo: 30, damage: 33, icon: "R" },
    { name: "VENDAS", type: "heal", ammo: 5, maxAmmo: 10, damage: 0, icon: "+" },
    { name: "", type: "empty", ammo: 0, maxAmmo: 0, damage: 0, icon: "" }
];
let selectedSlot = 0;
let shootCooldown = 0;
let muzzleFlashTimer = 0;
let hitMarkerTimer = 0;
let kills = 0;
let isReloading = false;
let reloadTimer = 0;
const RELOAD_TIME = 90;

const damageNumbers = [];

// ============================================================================
//  BUILDING SYSTEM
// ============================================================================
let buildMode = false;
let buildType = 0; // 0=wall, 1=ramp, 2=floor, 3=roof
let selectedMaterial = 0; // 0=wood, 1=stone, 2=metal
const buildNames = ["MURO", "RAMPA", "PISO", "TECHO"];
const buildCost = 10; // materiales por pieza

// Built structures array
const structures = [];
const MAX_STRUCTURES = 30;

// ============================================================================
//  ENEMIES (Bots)
// ============================================================================
const enemyData = [
];

const enemies = [];
for (let i = 0; i < enemyData.length; i++) {
    const obj = new RenderObject(playerMesh);
    obj.position = { x: enemyData[i].x, y: 0.0, z: enemyData[i].z };
    obj.scale = { x: 0.6, y: 0.6, z: 0.6 };
    obj.rotation = { x: -Math.PI / 2, y: 0.0, z: 0.0 };
    enemies.push({
        obj: obj,
        x: enemyData[i].x,
        y: 1.8,
        z: enemyData[i].z,
        alive: true,
        health: enemyData[i].hp,
        maxHealth: enemyData[i].hp,
        hitTimer: 0,
        moveTimer: 0,
        moveAngle: Math.random() * Math.PI * 2,
        shield: Math.floor(Math.random() * 50)
    });
}

let playersAlive = enemies.length + 1; // +1 for player

// ============================================================================
//  STORM SYSTEM
// ============================================================================
let stormRadius = 120.0;
let stormTargetRadius = 80.0;
let stormCenterX = 0.0;
let stormCenterZ = 0.0;
let stormPhase = 0;
let stormTimer = 1800; // 30 seconds at 60fps per phase
let stormDamage = 1;
let stormDamageTimer = 0;

// ============================================================================
//  SETUP
// ============================================================================
Camera.position(0.0, 1.8, 5.0);
const pad = Pads.get();

const hudCX = canvas.width / 2;
const hudCY = canvas.height / 2;

// ============================================================================
//  GAME LOOP
// ============================================================================
let frameCount = 0;
while (true) {
    Screen.clear(skyColor);
    Render.begin();
    pad.update();
    frameCount++;

    // ========================================================================
    //  ADS (Aim Down Sights) - L2
    // ========================================================================
    isAiming = pad.pressed(Pads.L2);
    const targetFOV = isAiming ? 45.0 : 70.0;
    currentFOV += (targetFOV - currentFOV) * 0.15;
    Render.setView(currentFOV, 0.5, 300.0);

    // ========================================================================
    //  INPUT - Camera
    // ========================================================================
    const aimMult = isAiming ? 0.5 : 1.0;
    const rstickX = ((pad.rx > 25 || pad.rx < -25) ? pad.rx : 0) / 3500.0 * aimMult;
    const rstickY = ((pad.ry > 25 || pad.ry < -25) ? pad.ry : 0) / 3500.0 * aimMult;

    yaw -= rstickX;
    pitch -= rstickY;
    if (pitch > 1.0) pitch = 1.0;
    if (pitch < -0.8) pitch = -0.8;

    // ========================================================================
    //  AIM ASSIST (solo cuando apunta con arma)
    // ========================================================================
    if (selectedSlot > 0 && inventory[selectedSlot].type !== "heal" && inventory[selectedSlot].type !== "empty") {
        const aimAssistActive = pad.justPressed(Pads.L2) || pad.pressed(Pads.R1);
        if (aimAssistActive) {
            let bestDist = 999.0;
            let targetYaw = yaw;
            let targetPitch = pitch;
            let found = false;

            for (let i = 0; i < enemies.length; i++) {
                if (!enemies[i].alive) continue;
                const dx = enemies[i].x - playerX;
                const chestY = enemies[i].y + 1.5;
                const dyChest = chestY - playerY;
                const dz = enemies[i].z - playerZ;

                const distH = Math.sqrt(dx * dx + dz * dz);
                const dist3d = Math.sqrt(dx * dx + dyChest * dyChest + dz * dz);
                if (dist3d < 0.5 || dist3d > 50.0) continue;

                const enemyYaw = Math.atan2(-dx, -dz);
                const chestPitch = Math.atan2(dyChest, distH);

                let dYaw = enemyYaw - yaw;
                while (dYaw > Math.PI) dYaw -= Math.PI * 2;
                while (dYaw < -Math.PI) dYaw += Math.PI * 2;

                if (Math.abs(dYaw) > 0.5) continue;

                if (dist3d < bestDist) {
                    bestDist = dist3d;
                    targetYaw = yaw + dYaw;
                    targetPitch = chestPitch;
                    found = true;
                }
            }

            if (found) {
                yaw += (targetYaw - yaw) * 0.15;
                pitch += (targetPitch - pitch) * 0.15;
                if (pitch > 1.0) pitch = 1.0;
                if (pitch < -0.8) pitch = -0.8;
            }
        }
    }

    // ========================================================================
    //  INPUT - Movement
    // ========================================================================
    const lstickX = ((pad.lx > 25 || pad.lx < -25) ? pad.lx : 0) / 128.0;
    const lstickY = ((pad.ly > 25 || pad.ly < -25) ? pad.ly : 0) / 128.0;

    const moveSpeed = 0.18;
    const sinYaw = Math.sin(yaw);
    const cosYaw = Math.cos(yaw);

    const moveX = (sinYaw * lstickY + cosYaw * lstickX) * moveSpeed;
    const moveZ = (cosYaw * lstickY - sinYaw * lstickX) * moveSpeed;

    playerX += moveX;
    playerZ += moveZ;

    // Character facing direction
    if (Math.abs(lstickX) > 0.1 || Math.abs(lstickY) > 0.1) {
        const stickAngle = Math.atan2(lstickX, -lstickY);
        playerYaw = yaw + stickAngle;
    }
    if (isAiming || pad.pressed(Pads.R1)) {
        playerYaw = yaw;
    }

    // Map boundaries
    if (playerX > 80.0) playerX = 80.0;
    if (playerX < -80.0) playerX = -80.0;
    if (playerZ > 80.0) playerZ = 80.0;
    if (playerZ < -80.0) playerZ = -80.0;

    // ========================================================================
    //  JUMP
    // ========================================================================
    if (pad.justPressed(Pads.CROSS) && isOnGround && !buildMode) {
        velocityY = 0.28;
        isOnGround = false;
    }

    velocityY -= 0.015;
    playerY += velocityY;

    // ========================================================================
    //  STRUCTURE COLLISION
    // ========================================================================
    let groundLevel = 1.8; // Default ground
    const pRadius = 0.8;

    for (let i = 0; i < structures.length; i++) {
        const s = structures[i];
        const dx = playerX - s.x;
        const dz = playerZ - s.z;
        const absDx = Math.abs(dx);
        const absDz = Math.abs(dz);

        if (s.type === 0) {
            // WALL collision - block horizontal movement
            // Wall is 6 wide, 6 tall, 0.4 thick (scale 3.0 * cube 2 = 6, 0.2 * 2 = 0.4)
            const wallHalfW = 6.0;  // wide axis
            const wallHalfT = 0.8;  // thin axis (with player radius)
            const wallTop = s.y + 3.0; // half of 6 height
            const wallBot = s.y - 3.0;

            if (playerY > wallBot && playerY - 1.8 < wallTop) {
                // Check wall orientation
                const wallRotY = s.obj.rotation.y;
                if (Math.abs(wallRotY) < 0.1 || Math.abs(wallRotY - Math.PI) < 0.1) {
                    // Wall faces Z (N/S) - blocks Z movement
                    if (absDx < wallHalfW && absDz < wallHalfT) {
                        playerZ -= dz > 0 ? -(wallHalfT - absDz) : (wallHalfT - absDz);
                    }
                } else {
                    // Wall faces X (E/W) - blocks X movement
                    if (absDz < wallHalfW && absDx < wallHalfT) {
                        playerX -= dx > 0 ? -(wallHalfT - absDx) : (wallHalfT - absDx);
                    }
                }
            }
        } else if (s.type === 1) {
            // RAMP - dynamic tilt calculation!
            const rampHalf = 3.0; // half of 6 units
            if (absDx < rampHalf && absDz < rampHalf) {
                const rotX = s.obj.rotation.x;
                const rotZ = s.obj.rotation.z;
                
                let surfaceY = s.y; // Center height
                const slopeFactor = 0.65; // Matches the physical tilt
                
                if (rotX > 0.1) surfaceY -= dz * slopeFactor;       // North: -Z is higher
                else if (rotX < -0.1) surfaceY += dz * slopeFactor; // South: +Z is higher
                else if (rotZ > 0.1) surfaceY += dx * slopeFactor;  // East: +X is higher
                else if (rotZ < -0.1) surfaceY -= dx * slopeFactor; // West: -X is higher
                
                const rampSurface = surfaceY + 1.8; // player eye height
                
                // If feet are roughly above or just below the ramp surface, snap up (walkable)
                // -2.5 allows stepping onto the bottom half without jumping
                if (playerY >= rampSurface - 2.8) {
                    if (rampSurface > groundLevel) {
                        groundLevel = rampSurface;
                    }
                }
            }
        } else if (s.type === 2 || s.type === 3) {
            // FLOOR / ROOF - walkable flat surface
            const floorHalf = 3.0;
            if (absDx < floorHalf && absDz < floorHalf) {
                const floorSurface = s.y + 0.15 + 1.8; // top of floor + eye height
                // Increase step-up range to easily transition from ramp top to floor
                if (playerY >= floorSurface - 2.8) {
                    if (floorSurface > groundLevel) {
                        groundLevel = floorSurface;
                    }
                }
            }
        }
    }

    // Ground check (world ground or structure surface)
    if (playerY <= groundLevel) {
        playerY = groundLevel;
        velocityY = 0.0;
        isOnGround = true;
    }

    // ========================================================================
    //  SLOT SELECTION (D-Pad LEFT/RIGHT)
    // ========================================================================
    if (!buildMode) {
        if (pad.justPressed(Pads.RIGHT)) {
            selectedSlot++;
            if (selectedSlot > 4) selectedSlot = 0;
        }
        if (pad.justPressed(Pads.LEFT)) {
            selectedSlot--;
            if (selectedSlot < 0) selectedSlot = 4;
        }
    }

    // ========================================================================
    //  BUILD MODE TOGGLE (CIRCLE) + BUILD TYPE (D-Pad in build mode)
    // ========================================================================
    if (pad.justPressed(Pads.CIRCLE)) {
        buildMode = !buildMode;
        if (buildMode) {
            selectedSlot = 0; // Switch to pickaxe while building
        }
    }

    // Compute preview build piece transform (used for preview + placement)
    // GRID SYSTEM: 4 build positions around player (N, E, S, W)
    // Cube is -1 to +1 (2 units), x3 scale = 6 units per piece
    const gridSize = 6.0;

    // Auto-select build direction based on camera yaw (0=N, 1=W, 2=S, 3=E)
    let normYaw = yaw % (Math.PI * 2);
    if (normYaw < 0) normYaw += Math.PI * 2;
    let buildDir = 0;
    if (normYaw < Math.PI * 0.25 || normYaw >= Math.PI * 1.75) buildDir = 0;      // North (-Z)
    else if (normYaw < Math.PI * 0.75) buildDir = 1;  // West (-X)
    else if (normYaw < Math.PI * 1.25) buildDir = 2;  // South (+Z)
    else buildDir = 3;                                  // East (+X)

    // Place rigidly exactly one grid cell in front of where the player is currently standing
    // This fixes structures placing 'behind' or skipping cells
    const playerGridX = Math.round(playerX / gridSize) * gridSize;
    const playerGridZ = Math.round(playerZ / gridSize) * gridSize;
    const dirOffX = [0, -1, 0, 1];
    const dirOffZ = [-1, 0, 1, 0];
    const prevPX = playerGridX + dirOffX[buildDir] * gridSize;
    const prevPZ = playerGridZ + dirOffZ[buildDir] * gridSize;

    // Smart vertical leveling: Determine base height based on player's feet.
    // Base is 1.5, next is 7.5, next is 13.5
    // If looking upwards (pitch > 0.2) and building a ramp, boost it by one level to chain staircases!
    let levelBase = 1.5 + Math.max(0, Math.floor((playerY - 2.5) / 5.0)) * 6.0;
    if (buildType === 1 && pitch > 0.2) {
        levelBase += 6.0;
    }

    let prevScaleX = 3.0, prevScaleY = 3.0, prevScaleZ = 0.2;
    let prevPosY = levelBase, prevRotX = 0.0, prevRotY = 0.0, prevRotZ = 0.0;

    if (buildType === 0) {
        // WALL - perpendicular to build direction
        prevScaleX = 3.0; prevScaleY = 3.0; prevScaleZ = 0.2;
        prevPosY = 1.5;
        prevRotY = (buildDir === 1 || buildDir === 3) ? Math.PI / 2 : 0;
    } else if (buildType === 1) {
        // RAMP - use per-axis tilt to avoid Euler distortion
        prevScaleX = 3.0; prevScaleY = 0.2; prevScaleZ = 3.0;
        prevPosY = 1.5;
        const slope = 0.6;
        if (buildDir === 0) { prevRotX = slope; }        // North
        else if (buildDir === 1) { prevRotZ = -slope; }   // West
        else if (buildDir === 2) { prevRotX = -slope; }   // South
        else { prevRotZ = slope; }                          // East
    } else if (buildType === 2) {
        // FLOOR - flat on the grid bottom line
        prevScaleX = 3.0; prevScaleY = 0.15; prevScaleZ = 3.0;
        prevPosY = 3.0;
    } else {
        // ROOF - small tilt
        prevScaleX = 3.0; prevScaleY = 0.15; prevScaleZ = 3.0;
        prevPosY = 5.0;
        const slope = 0.3;
        if (buildDir === 0) { prevRotX = slope; }
        else if (buildDir === 1) { prevRotZ = -slope; }
        else if (buildDir === 2) { prevRotX = -slope; }
        else { prevRotZ = slope; }
    }

    // Check if a structure already exists at this grid position + height
    // If occupied, try stacking (find next free Y level for bridges)
    let placePosY = prevPosY;
    let spotOccupied = false;
    for (let attempt = 0; attempt < 5; attempt++) {
        let found = false;
        for (let i = 0; i < structures.length; i++) {
            const s = structures[i];
            if (Math.abs(s.x - prevPX) < 1.0 && Math.abs(s.z - prevPZ) < 1.0 && Math.abs(s.y - placePosY) < 1.0) {
                found = true;
                break;
            }
        }
        if (!found) break; // Free spot found
        // Try next level up (6 units = one piece height)
        placePosY += 6.0;
        if (attempt === 4) spotOccupied = true; // Max 5 levels high
    }

    // Update preview object transform (using placePosY to show stacking)
    previewObj.position = { x: prevPX, y: placePosY, z: prevPZ };
    previewObj.scale = { x: prevScaleX, y: prevScaleY, z: prevScaleZ };
    previewObj.rotation = { x: prevRotX, y: prevRotY, z: prevRotZ };

    if (buildMode) {
        // Switch build piece type
        if (pad.justPressed(Pads.RIGHT)) {
            buildType++;
            if (buildType > 3) buildType = 0;
        }
        if (pad.justPressed(Pads.LEFT)) {
            buildType--;
            if (buildType < 0) buildType = 3;
        }

        // Switch material with D-Pad UP/DOWN
        if (pad.justPressed(Pads.UP)) {
            selectedMaterial++;
            if (selectedMaterial > 2) selectedMaterial = 0;
        }
        if (pad.justPressed(Pads.DOWN)) {
            selectedMaterial--;
            if (selectedMaterial < 0) selectedMaterial = 2;
        }

        // Place structure with R1 (only if spot is free)
        if (pad.justPressed(Pads.R1) && !spotOccupied) {
            // Check materials
            let hasEnough = false;
            if (selectedMaterial === 0 && woodCount >= buildCost) { woodCount -= buildCost; hasEnough = true; }
            if (selectedMaterial === 1 && stoneCount >= buildCost) { stoneCount -= buildCost; hasEnough = true; }
            if (selectedMaterial === 2 && metalCount >= buildCost) { metalCount -= buildCost; hasEnough = true; }

            if (hasEnough && structures.length < MAX_STRUCTURES) {
                const piece = new RenderObject(cubeMesh);
                piece.position = { x: prevPX, y: placePosY, z: prevPZ };
                piece.scale = { x: prevScaleX, y: prevScaleY, z: prevScaleZ };
                piece.rotation = { x: prevRotX, y: prevRotY, z: prevRotZ };

                structures.push({
                    obj: piece,
                    x: prevPX, y: placePosY, z: prevPZ,
                    type: buildType,
                    material: selectedMaterial,
                    health: (selectedMaterial === 0) ? 150 : (selectedMaterial === 1) ? 300 : 500
                });
            }
        }
    }

    // ========================================================================
    //  SHOOTING / PICKAXE
    // ========================================================================
    if (shootCooldown > 0) shootCooldown--;

    if (isReloading) {
        reloadTimer--;
        if (reloadTimer <= 0) {
            inventory[selectedSlot].ammo = inventory[selectedSlot].maxAmmo;
            isReloading = false;
        }
    }

    // Reload with L1
    if (pad.justPressed(Pads.L1) && !isReloading && !buildMode && selectedSlot > 0) {
        const item = inventory[selectedSlot];
        if (item.type !== "empty" && item.type !== "heal" && item.ammo < item.maxAmmo) {
            isReloading = true;
            reloadTimer = RELOAD_TIME;
        }
    }

    // Heal with R1 when bandage selected
    if (selectedSlot === 3 && inventory[3].type === "heal" && pad.justPressed(Pads.R1) && !buildMode) {
        if (inventory[3].ammo > 0 && health < maxHealth) {
            health += 25;
            if (health > maxHealth) health = maxHealth;
            inventory[3].ammo--;
        }
    }

    // Shoot / Pickaxe swing
    if (!buildMode && pad.pressed(Pads.R1) && shootCooldown <= 0 && !isReloading && selectedSlot !== 3) {
        const item = inventory[selectedSlot];

        if (item.type === "pickaxe") {
            // Pickaxe swing - harvest
            shootCooldown = 15;
            // Harvest: add materials if hitting something
            woodCount += 5;
            if (woodCount > 999) woodCount = 999;
        } else if (item.type === "shotgun") {
            shootCooldown = 20;
            muzzleFlashTimer = 3;
            // Shotgun does not consume ammo forever for fun
        } else if (item.type === "rifle") {
            shootCooldown = 6;
            muzzleFlashTimer = 3;
        }

        // Raycast for damage (weapons only)
        if (item.type !== "pickaxe" && item.type !== "heal" && item.type !== "empty") {
            const cosPch = Math.cos(pitch);
            const dirX = -Math.sin(yaw) * cosPch;
            const dirY = Math.sin(pitch);
            const dirZ = -Math.cos(yaw) * cosPch;

            let closestDist = 999.0;
            let closestEnemy = -1;
            let isHeadshot = false;

            for (let i = 0; i < enemies.length; i++) {
                const en = enemies[i];
                if (!en.alive) continue;

                const ex = en.x - playerX;
                const ez = en.z - playerZ;

                // Chest hitbox
                const chestY = (en.y + 1.5) - playerY;
                const dotChest = ex * dirX + chestY * dirY + ez * dirZ;
                if (dotChest > 0) {
                    const cpx = dirX * dotChest - ex;
                    const cpy = dirY * dotChest - chestY;
                    const cpz = dirZ * dotChest - ez;
                    const distChest = Math.sqrt(cpx * cpx + cpy * cpy + cpz * cpz);
                    if (distChest < 0.8 && dotChest < closestDist) {
                        closestDist = dotChest;
                        closestEnemy = i;
                        isHeadshot = false;
                    }
                }

                // Head hitbox
                const headY = (en.y + 2.4) - playerY;
                const dotHead = ex * dirX + headY * dirY + ez * dirZ;
                if (dotHead > 0) {
                    const cpx2 = dirX * dotHead - ex;
                    const cpy2 = dirY * dotHead - headY;
                    const cpz2 = dirZ * dotHead - ez;
                    const distHead = Math.sqrt(cpx2 * cpx2 + cpy2 * cpy2 + cpz2 * cpz2);
                    if (distHead < 0.4 && dotHead < closestDist) {
                        closestDist = dotHead;
                        closestEnemy = i;
                        isHeadshot = true;
                    }
                }
            }

            if (closestEnemy >= 0) {
                let dmg = item.damage + Math.floor(Math.random() * 10);
                if (isHeadshot) dmg = Math.floor(dmg * 2.5);

                // Damage shield first
                const en = enemies[closestEnemy];
                if (en.shield > 0) {
                    const shieldDmg = Math.min(dmg, en.shield);
                    en.shield -= shieldDmg;
                    dmg -= shieldDmg;
                }
                en.health -= dmg;
                en.hitTimer = 8;
                hitMarkerTimer = 10;

                damageNumbers.push({
                    x: hudCX + (Math.random() * 40 - 20),
                    y: hudCY - 30 + (Math.random() * 20 - 10),
                    amount: item.damage + Math.floor(Math.random() * 10),
                    life: 40,
                    isCrit: isHeadshot
                });

                if (en.health <= 0) {
                    en.alive = false;
                    kills++;
                    playersAlive--;

                    // Drop materials on kill
                    woodCount += 30 + Math.floor(Math.random() * 50);
                    stoneCount += 10 + Math.floor(Math.random() * 30);
                    if (woodCount > 999) woodCount = 999;
                    if (stoneCount > 999) stoneCount = 999;
                }
            }
        }
    }

    // ========================================================================
    //  ENEMY AI (Simple patrol + face player)
    // ========================================================================
    for (let i = 0; i < enemies.length; i++) {
        const en = enemies[i];
        if (!en.alive) continue;

        en.moveTimer++;
        if (en.moveTimer > 120) {
            en.moveTimer = 0;
            en.moveAngle = Math.random() * Math.PI * 2;
        }

        // Move slowly (update every other frame)
        if ((frameCount + i) % 2 === 0) {
            en.x += Math.sin(en.moveAngle) * 0.06;
            en.z += Math.cos(en.moveAngle) * 0.06;
        }

        // Keep in bounds
        if (en.x > 75) en.x = 75;
        if (en.x < -75) en.x = -75;
        if (en.z > 75) en.z = 75;
        if (en.z < -75) en.z = -75;

        // Face player if close (use distSq to avoid sqrt)
        const dx = playerX - en.x;
        const dz = playerZ - en.z;
        const distSq = dx * dx + dz * dz;
        if (distSq < 900) { // 30^2
            const dist = Math.sqrt(distSq);
            const faceAngle = Math.atan2(dx, dz);
            en.obj.rotation = { x: -Math.PI / 2, y: 0.0, z: faceAngle + Math.PI / 2 };

            // Chase player if close
            if (dist < 20 && dist > 3) {
                en.x += (dx / dist) * 0.05;
                en.z += (dz / dist) * 0.05;
            }

            // Shoot at player if very close (damage player)
            if (dist < 15 && en.moveTimer % 60 === 0) {
                let dmg = 5 + Math.floor(Math.random() * 5);
                if (shield > 0) {
                    const shieldDmg = Math.min(dmg, shield);
                    shield -= shieldDmg;
                    dmg -= shieldDmg;
                }
                health -= dmg;
            }
        }

        en.obj.position = { x: en.x, y: 0.0, z: en.z };
    }

    // ========================================================================
    //  STORM SYSTEM
    // ========================================================================
    stormTimer--;
    if (stormTimer <= 0) {
        stormPhase++;
        stormTimer = 1800;
        stormTargetRadius *= 0.7;
        if (stormTargetRadius < 10) stormTargetRadius = 10;
        stormDamage += 1;
    }

    // Shrink storm
    if (stormRadius > stormTargetRadius) {
        stormRadius -= 0.02;
    }

    // Storm damage to player
    const playerDistFromCenter = Math.sqrt(
        (playerX - stormCenterX) * (playerX - stormCenterX) +
        (playerZ - stormCenterZ) * (playerZ - stormCenterZ)
    );
    if (playerDistFromCenter > stormRadius) {
        stormDamageTimer++;
        if (stormDamageTimer >= 60) {
            stormDamageTimer = 0;
            health -= stormDamage;
        }
    }

    // Storm damage to enemies (check every 2 seconds)
    if (frameCount % 120 === 0) {
        const stormRadSq = stormRadius * stormRadius;
        for (let i = 0; i < enemies.length; i++) {
            const en = enemies[i];
            if (!en.alive) continue;
            const edx = en.x - stormCenterX;
            const edz = en.z - stormCenterZ;
            if ((edx * edx + edz * edz) > stormRadSq) {
                en.health -= stormDamage;
                if (en.health <= 0) {
                    en.alive = false;
                    playersAlive--;
                }
            }
        }
    }

    // Check death
    if (health <= 0) health = 0;

    // ========================================================================
    //  CAMERA (Third Person always)
    // ========================================================================
    const cosPitch = Math.cos(pitch);
    const fwdX = -Math.sin(yaw) * cosPitch;
    const fwdY = Math.sin(pitch);
    const fwdZ = -Math.cos(yaw) * cosPitch;

    const camDist = isAiming ? 4.0 : 7.0;
    const camHeight = isAiming ? 0.6 : 1.2;
    // Camera offset to the right shoulder
    const rightX = Math.cos(yaw);
    const rightZ = -Math.sin(yaw);
    const shoulderOffset = 1.0;

    const camX = playerX - fwdX * camDist + rightX * shoulderOffset;
    const camY = playerY + camHeight - fwdY * camDist;
    const camZ = playerZ - fwdZ * camDist + rightZ * shoulderOffset;

    Camera.position(camX, camY, camZ);
    Camera.target(playerX + fwdX * 5.0, playerY + 0.8 + fwdY * 5.0, playerZ + fwdZ * 5.0);
    Camera.update();

    // Update player model
    playerModel.position = { x: playerX, y: playerY - 1.8, z: playerZ };
    playerModel.rotation = { x: -Math.PI / 2, y: 0.0, z: playerYaw + Math.PI / 2 };

    // ========================================================================
    //  RENDER 3D
    // ========================================================================
    Screen.setParam(Screen.DEPTH_TEST_ENABLE, true);
    Screen.setParam(Screen.DEPTH_TEST_METHOD, Screen.DEPTH_GEQUAL);

    groundObj.render();
    playerModel.render();

    // Render enemies
    for (let i = 0; i < enemies.length; i++) {
        const en = enemies[i];
        if (!en.alive) continue;
        if (en.hitTimer > 0) en.hitTimer--;

        const dx = en.x - playerX;
        const dz = en.z - playerZ;
        const distSq = dx * dx + dz * dz;
        if (distSq > 2500.0) continue; // 50^2 render distance

        en.obj.render();
    }

    // Render structures (cull by distance)
    for (let i = 0; i < structures.length; i++) {
        const sdx = structures[i].x - playerX;
        const sdz = structures[i].z - playerZ;
        if (sdx * sdx + sdz * sdz > 2500.0) continue;
        structures[i].obj.render();
    }

    // Render build preview (ghost piece) in build mode
    if (buildMode) {
        previewObj.render();
    }

    Screen.setParam(Screen.DEPTH_TEST_ENABLE, false);

    // ========================================================================
    //  HUD - FORTNITE STYLE
    // ========================================================================

    // --- COMPASS (top center) ---
    const compassW = 200;
    const compassH = 18;
    const compassX = hudCX - compassW / 2;
    const compassY = 8;
    Draw.rect(compassX, compassY, compassW, compassH, compassBg);

    // Direction letters
    const dirs = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    const dirAngles = [0, Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4, Math.PI, -3 * Math.PI / 4, -Math.PI / 2, -Math.PI / 4];

    font.scale = 0.65;
    font.color = white;
    for (let i = 0; i < dirs.length; i++) {
        let diff = dirAngles[i] - yaw;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;

        if (Math.abs(diff) < 0.8) {
            const sx = hudCX + (diff / 0.8) * (compassW / 2);
            font.print(sx - 4, compassY + 3, dirs[i]);
        }
    }

    // Center notch
    Draw.line(hudCX, compassY, hudCX, compassY + 5, white);

    // --- CROSSHAIR ---
    const crossColor = (hitMarkerTimer > 0) ? red : white;
    if (buildMode) {
        // Build mode crosshair (circle-ish)
        const cr = 12;
        Draw.line(hudCX - cr, hudCY, hudCX - cr + 5, hudCY, cyan);
        Draw.line(hudCX + cr - 5, hudCY, hudCX + cr, hudCY, cyan);
        Draw.line(hudCX, hudCY - cr, hudCX, hudCY - cr + 5, cyan);
        Draw.line(hudCX, hudCY + cr - 5, hudCX, hudCY + cr, cyan);
    } else {
        const crossSize = isAiming ? 5 : 10;
        const crossGap = isAiming ? 2 : 4;
        Draw.line(hudCX - crossSize, hudCY, hudCX - crossGap, hudCY, crossColor);
        Draw.line(hudCX + crossGap, hudCY, hudCX + crossSize, hudCY, crossColor);
        Draw.line(hudCX, hudCY - crossSize, hudCX, hudCY - crossGap, crossColor);
        Draw.line(hudCX, hudCY + crossGap, hudCX, hudCY + crossSize, crossColor);
    }

    // Hit marker
    if (hitMarkerTimer > 0) {
        hitMarkerTimer--;
        Draw.line(hudCX - 6, hudCY - 6, hudCX - 2, hudCY - 2, white);
        Draw.line(hudCX + 6, hudCY - 6, hudCX + 2, hudCY - 2, white);
        Draw.line(hudCX - 6, hudCY + 6, hudCX - 2, hudCY + 2, white);
        Draw.line(hudCX + 6, hudCY + 6, hudCX + 2, hudCY + 2, white);
    }

    // Floating damage numbers
    font.scale = 0.7;
    for (let i = damageNumbers.length - 1; i >= 0; i--) {
        const dn = damageNumbers[i];
        dn.y -= 1.0;
        dn.life--;
        font.color = dn.isCrit ? dmgColorCrit : dmgColorNormal;
        font.print(dn.x, dn.y, "" + dn.amount);
        if (dn.life <= 0) {
            damageNumbers.splice(i, 1);
        }
    }

    // --- MUZZLE FLASH ---
    if (muzzleFlashTimer > 0) {
        muzzleFlashTimer--;
        Draw.rect(hudCX + 72, hudCY + 42, 16, 16, muzzleC);
        Draw.rect(hudCX + 76, hudCY + 38, 8, 24, muzzleC);
    }

    // --- HEALTH & SHIELD BARS (bottom left, Fortnite style) ---
    const barX = 20;
    const barW = 160;
    const barH = 14;

    // Shield bar (blue)
    const shieldY = canvas.height - 62;
    Draw.rect(barX - 2, shieldY - 2, barW + 4, barH + 4, semiBlack2);
    Draw.rect(barX, shieldY, barW, barH, shieldBg);
    const shieldFill = Math.floor((shield / maxShield) * barW);
    if (shieldFill > 0) Draw.rect(barX, shieldY, shieldFill, barH, shieldColor);

    // Shield icon + text
    font.scale = 0.6;
    font.color = shieldColor;
    font.print(barX + barW + 8, shieldY, shield + "");

    // Small shield icon (diamond shape with lines)
    const siX = barX - 14;
    const siY = shieldY + 2;
    Draw.line(siX + 4, siY, siX + 8, siY + 4, shieldColor);
    Draw.line(siX + 8, siY + 4, siX + 4, siY + 8, shieldColor);
    Draw.line(siX + 4, siY + 8, siX, siY + 4, shieldColor);
    Draw.line(siX, siY + 4, siX + 4, siY, shieldColor);

    // Health bar (green)
    const healthY = canvas.height - 46;
    Draw.rect(barX - 2, healthY - 2, barW + 4, barH + 4, semiBlack2);
    Draw.rect(barX, healthY, barW, barH, healthBg);
    const healthFill = Math.floor((health / maxHealth) * barW);
    const healthBarColor = (health > 60) ? healthColor : (health > 25 ? yellow : red);
    if (healthFill > 0) Draw.rect(barX, healthY, healthFill, barH, healthBarColor);

    // Health icon + text
    font.scale = 0.6;
    font.color = healthBarColor;
    font.print(barX + barW + 8, healthY, health + "");

    // Cross icon for health
    const hiX = barX - 12;
    const hiY = healthY + 2;
    Draw.rect(hiX + 2, hiY, 4, 8, healthBarColor);
    Draw.rect(hiX, hiY + 2, 8, 4, healthBarColor);

    // --- INVENTORY SLOTS (bottom center) ---
    const slotW = 40;
    const slotH = 40;
    const slotGap = 4;
    const totalSlotW = 5 * slotW + 4 * slotGap;
    const slotStartX = hudCX - totalSlotW / 2;
    const slotY = canvas.height - slotH - 8;

    for (let i = 0; i < 5; i++) {
        const sx = slotStartX + i * (slotW + slotGap);

        // Slot background
        Draw.rect(sx, slotY, slotW, slotH, slotBg);

        // Selected highlight border
        if (i === selectedSlot && !buildMode) {
            // Draw border lines
            Draw.line(sx, slotY, sx + slotW, slotY, slotSelected);
            Draw.line(sx + slotW, slotY, sx + slotW, slotY + slotH, slotSelected);
            Draw.line(sx + slotW, slotY + slotH, sx, slotY + slotH, slotSelected);
            Draw.line(sx, slotY + slotH, sx, slotY, slotSelected);
        } else {
            Draw.line(sx, slotY, sx + slotW, slotY, slotBorder);
            Draw.line(sx + slotW, slotY, sx + slotW, slotY + slotH, slotBorder);
            Draw.line(sx + slotW, slotY + slotH, sx, slotY + slotH, slotBorder);
            Draw.line(sx, slotY + slotH, sx, slotY, slotBorder);
        }

        // Item icon/text
        if (inventory[i].type !== "empty") {
            // Icon letter (big)
            font.scale = 0.8;
            if (i === 0) font.color = white;
            else if (inventory[i].type === "shotgun") font.color = orange;
            else if (inventory[i].type === "rifle") font.color = cyan;
            else if (inventory[i].type === "heal") font.color = green;
            else font.color = white;

            font.print(sx + 10, slotY + 6, inventory[i].icon);

            // Ammo count (small, bottom of slot)
            if (inventory[i].ammo >= 0) {
                font.scale = 0.5;
                font.color = grayText;
                font.print(sx + 4, slotY + slotH - 12, inventory[i].ammo + "");
            }
        }
    }

    // Weapon name under slots
    if (!buildMode && inventory[selectedSlot].type !== "empty") {
        font.scale = 0.6;
        font.color = white;
        const nameW = inventory[selectedSlot].name.length * 8;
        font.print(hudCX - nameW / 2, slotY - 18, inventory[selectedSlot].name);
    }

    // --- AMMO DISPLAY (bottom right of slots) ---
    if (selectedSlot > 0 && inventory[selectedSlot].type !== "empty" && inventory[selectedSlot].type !== "heal" && !buildMode) {
        const ammoX = slotStartX + totalSlotW + 10;
        const ammoY = slotY + 8;
        Draw.rect(ammoX - 4, ammoY - 4, 55, 30, semiBlack);

        font.scale = 0.8;
        font.color = white;
        if (isReloading) {
            font.color = yellow;
            font.print(ammoX, ammoY, "...");
            // Reload progress bar
            const prog = 1.0 - (reloadTimer / RELOAD_TIME);
            Draw.rect(ammoX, ammoY + 18, 45, 4, darkGray);
            Draw.rect(ammoX, ammoY + 18, Math.floor(45 * prog), 4, yellow);
        } else {
            font.print(ammoX, ammoY, inventory[selectedSlot].ammo + "");
        }
    }

    // --- BUILD MODE HUD (right side) ---
    if (buildMode) {
        // Build mode indicator
        const bmX = canvas.width - 110;
        const bmY = canvas.height - 160;

        Draw.rect(bmX - 4, bmY - 4, 108, 130, semiBlack2);

        font.scale = 0.65;
        font.color = cyan;
        font.print(bmX, bmY, "CONSTRUIR");

        // Build types
        const btNames = ["MURO", "RAMPA", "PISO", "TECHO"];
        for (let i = 0; i < 4; i++) {
            const by = bmY + 18 + i * 18;
            if (i === buildType) {
                Draw.rect(bmX - 2, by - 1, 100, 16, buildHighlight);
                font.color = white;
            } else {
                font.color = grayText;
            }
            font.scale = 0.6;
            font.print(bmX + 4, by, btNames[i]);
        }

        // Material indicator
        const matY = bmY + 95;
        const matNames = ["MADERA", "PIEDRA", "METAL"];
        const matColors = [buildWood, buildStone, buildMetal];
        const matCounts = [woodCount, stoneCount, metalCount];

        Draw.rect(bmX, matY, 8, 8, matColors[selectedMaterial]);
        font.scale = 0.6;
        font.color = matColors[selectedMaterial];
        font.print(bmX + 12, matY, matNames[selectedMaterial]);
        font.print(bmX + 12, matY + 12, matCounts[selectedMaterial] + "");
    }

    // --- MATERIALS DISPLAY (bottom right, always visible) ---
    const matDispX = canvas.width - 105;
    const matDispY = canvas.height - 50;
    Draw.rect(matDispX - 4, matDispY - 4, 100, 42, semiBlack);

    font.scale = 0.55;
    // Wood
    Draw.rect(matDispX, matDispY + 2, 6, 6, buildWood);
    font.color = buildWood;
    font.print(matDispX + 10, matDispY, woodCount + "");
    // Stone
    Draw.rect(matDispX + 35, matDispY + 2, 6, 6, buildStone);
    font.color = buildStone;
    font.print(matDispX + 45, matDispY, stoneCount + "");
    // Metal
    Draw.rect(matDispX + 70, matDispY + 2, 6, 6, buildMetal);
    font.color = buildMetal;
    font.print(matDispX + 80, matDispY, metalCount + "");

    // --- MINIMAP (top right, Fortnite style circular) ---
    const mmSize = 70;
    const mmX = canvas.width - mmSize - 12;
    const mmY = 30;
    const mmCX = mmX + mmSize / 2;
    const mmCY = mmY + mmSize / 2;
    const mmScale = mmSize / 200.0;

    // Background
    Draw.rect(mmX, mmY, mmSize, mmSize, minimapBg);
    // Border
    Draw.line(mmX, mmY, mmX + mmSize, mmY, minimapBorder);
    Draw.line(mmX + mmSize, mmY, mmX + mmSize, mmY + mmSize, minimapBorder);
    Draw.line(mmX + mmSize, mmY + mmSize, mmX, mmY + mmSize, minimapBorder);
    Draw.line(mmX, mmY + mmSize, mmX, mmY, minimapBorder);

    // Storm circle on minimap
    const stormMmR = stormRadius * mmScale;
    const stormMmCX = mmCX + (stormCenterX - playerX) * mmScale;
    const stormMmCY = mmCY + (stormCenterZ - playerZ) * mmScale;
    // Draw storm as lines (approximation)
    const stormSegs = 8;
    for (let s = 0; s < stormSegs; s++) {
        const a1 = (s / stormSegs) * Math.PI * 2;
        const a2 = ((s + 1) / stormSegs) * Math.PI * 2;
        const sx1 = stormMmCX + Math.cos(a1) * stormMmR;
        const sy1 = stormMmCY + Math.sin(a1) * stormMmR;
        const sx2 = stormMmCX + Math.cos(a2) * stormMmR;
        const sy2 = stormMmCY + Math.sin(a2) * stormMmR;
        Draw.line(sx1, sy1, sx2, sy2, stormMinimap);
    }

    // Enemies on minimap (only close ones)
    for (let i = 0; i < enemies.length; i++) {
        if (!enemies[i].alive) continue;
        const dx = enemies[i].x - playerX;
        const dz = enemies[i].z - playerZ;
        if (dx * dx + dz * dz < 900) { // 30^2
            const ex = mmCX + dx * mmScale;
            const ez = mmCY + dz * mmScale;
            if (ex > mmX && ex < mmX + mmSize && ez > mmY && ez < mmY + mmSize) {
                Draw.rect(ex - 1, ez - 1, 3, 3, red);
            }
        }
    }

    // Player on minimap (center, with direction)
    Draw.rect(mmCX - 2, mmCY - 2, 4, 4, white);
    const pDirX = -Math.sin(yaw) * 5;
    const pDirZ = -Math.cos(yaw) * 5;
    Draw.line(mmCX, mmCY, mmCX + pDirX, mmCY + pDirZ, white);

    // --- PLAYER COUNT & KILLS (top right, above minimap) ---
    const infoX = canvas.width - 90;
    const infoY = 8;
    Draw.rect(infoX - 4, infoY - 2, 86, 20, semiBlack);

    font.scale = 0.65;
    font.color = white;
    font.print(infoX, infoY, playersAlive + "");
    font.color = grayText;
    font.print(infoX + 18, infoY, "vivos");

    font.color = goldColor;
    font.print(infoX + 52, infoY, kills + "");
    font.color = grayText;
    font.print(infoX + 66, infoY, "kills");

    // --- FPS ---
    font.color = white;
    font.scale = 0.6;
    font.print(10, 10, Screen.getFPS(360) + " FPS");

    // --- STORM WARNING ---
    if (playerDistFromCenter > stormRadius) {
        font.scale = 0.8;
        font.color = stormMinimap;
        font.print(hudCX - 80, 35, "FUERA DE LA ZONA!");
    }

    // --- STORM TIMER ---
    const stormSecs = Math.floor(stormTimer / 60);
    const stormMins = Math.floor(stormSecs / 60);
    const stormRemSecs = stormSecs % 60;
    font.scale = 0.6;
    font.color = grayText;
    font.print(mmX, mmY + mmSize + 4, stormMins + ":" + (stormRemSecs < 10 ? "0" : "") + stormRemSecs);

    // --- CONTROLS HELP ---
    font.scale = 0.5;
    font.color = controlsColor;
    if (buildMode) {
        font.print(10, canvas.height - 14, "LR:PIEZA UD:MAT R1:BUILD O:SALIR");
    } else {
        font.print(10, canvas.height - 14, "R1:SHOOT L1:RELOAD L2:ADS LR:SLOT O:BUILD");
    }

    // --- GAME OVER (hidden for now) ---
    // if (health <= 0) {
    //     Draw.rect(hudCX - 120, hudCY - 50, 240, 60, semiBlack2);
    //     font.scale = 1.0;
    //     font.color = red;
    //     font.print(hudCX - 90, hudCY - 40, "ELIMINADO");
    //     font.scale = 0.7;
    //     font.color = white;
    //     font.print(hudCX - 60, hudCY - 10, "#" + playersAlive + " de " + (enemies.length + 1));
    //     font.scale = 0.65;
    //     font.color = grayText;
    //     font.print(hudCX - 40, hudCY + 10, kills + " kills");
    // }

    // --- VICTORY ROYALE (hidden for now) ---
    // if (playersAlive <= 1 && health > 0) {
    //     Draw.rect(hudCX - 130, hudCY - 60, 260, 70, semiBlack2);
    //     font.scale = 1.1;
    //     font.color = goldColor;
    //     font.print(hudCX - 130, hudCY - 50, "VICTORIA ROYALE!");
    //     font.scale = 0.75;
    //     font.color = white;
    //     font.print(hudCX - 65, hudCY - 12, kills + " eliminaciones");
    // }

    Screen.flip();
}
