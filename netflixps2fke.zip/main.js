//////////////////////////////////////////////////////////////////////////
///*                          NETFLIX PS2                              *///
///*                  Sistema de Streaming Estilo Netflix              *///
//////////////////////////////////////////////////////////////////////////

// Configuración de pantalla
const screenWidth = 640;
const screenHeight = 448;

// Colores Netflix
const colors = {
    background: Color.new(20, 20, 20, 255),
    netflixRed: Color.new(229, 9, 20, 255),
    white: Color.new(255, 255, 255, 255),
    gray: Color.new(100, 100, 100, 255),
    black: Color.new(0, 0, 0, 255)
};

// Layout del header
const headerHeight = 80;

// Estado del menú
let selectedMenu = 0;
const menuItems = ["Inicio", "Series", "Peliculas", "Mi Lista"];

// Estado de navegación en categorías
let currentCategory = 0;
let currentItem = 0;

// Scroll suave vertical (categorías)
let scrollOffset = 0;
let targetScrollOffset = 0;

// Scroll horizontal por categoría (películas)
let horizontalScroll = [0, 0, 0]; // Un scroll por cada categoría
let targetHorizontalScroll = [0, 0, 0];

let inputDelay = 0;
const INPUT_COOLDOWN = 10;

// Categorías
const categories = [
    {
        name: "Tendencias",
        items: [
            { title: "Avengers", id: "avengers" },
            { title: "The Flash", id: "theflash" },
            { title: "El Chavo", id: "elchavo" },
            { title: "Pelicula 4", id: "pelicula4" },
            { title: "Pelicula 5", id: "pelicula5" }
        ]
    },
    {
        name: "Accion",
        items: [
            { title: "Accion 1", id: "accion1" },
            { title: "Accion 2", id: "accion2" },
            { title: "Accion 3", id: "accion3" },
            { title: "Accion 4", id: "accion4" },
            { title: "Accion 5", id: "accion5" }
        ]
    },
    {
        name: "Comedia",
        items: [
            { title: "Comedia 1", id: "comedia1" },
            { title: "Comedia 2", id: "comedia2" },
            { title: "Comedia 3", id: "comedia3" },
            { title: "Comedia 4", id: "comedia4" },
            { title: "Comedia 5", id: "comedia5" }
        ]
    }
];

// Layout para items
const itemWidth = 200;
const itemHeight = 120;
const itemSpacing = 15;

// Configuración de red
const GITHUB_BASE_URL = "https://raw.githubusercontent.com/eunaousoia/Netflix-PS2-Covers/main/covers/";
const CWD = os.getcwd()[0];
const COVERS_PATH = `${CWD}/covers/`;
let loadedCovers = {}; // Cache de portadas cargadas

// Estado de red (igual que OSDXMB)
const NetInfo = {
    Initialized: false,
    IP: "-"
};


//////////////////////////////////////////////////////////////////////////
///*                      Funciones de Red                             *///
//////////////////////////////////////////////////////////////////////////

function NetInit() {
    try {
        // Verificar si la red ya está disponible
        const conf = Network.getConfig();
        if (conf && conf.ip && conf.ip !== "0.0.0.0") {
            NetInfo.Initialized = true;
            NetInfo.IP = conf.ip;
            console.log(`Red disponible: ${NetInfo.IP}`);
            return true;
        }
        
        // Si no hay red, cargar módulo de red y usar DHCP
        console.log("Cargando módulo de red...");
        IOP.loadDefaultModule(IOP.network); // Correcto según doc.txt línea 646
        
        console.log("Inicializando DHCP...");
        Network.init(); // DHCP automático (doc.txt línea 663)
        
        const newConf = Network.getConfig();
        if (newConf && newConf.ip && newConf.ip !== "0.0.0.0") {
            NetInfo.Initialized = true;
            NetInfo.IP = newConf.ip;
            console.log(`Red inicializada: ${NetInfo.IP}`);
            return true;
        }
        
        console.log("No se pudo obtener IP por DHCP");
        return false;
    } catch (e) {
        console.log(`Error inicializando red: ${e}`);
        return false;
    }
}

function downloadCover(movieId) {
    // Intentar con PNG y JPG
    const extensions = ['.png', '.jpg'];
    
    for (let ext of extensions) {
        const localPath = `${COVERS_PATH}${movieId}${ext}`;
        
        // Si ya existe localmente, no descargar
        if (std.exists(localPath)) {
            console.log(`Ya existe: ${movieId}${ext}`);
            return localPath;
        }
    }
    
    // Verificar si hay red
    if (!NetInfo.Initialized) {
        console.log("Red no disponible - no se puede descargar");
        return null;
    }
    
    // Intentar descargar con ambos formatos
    for (let ext of extensions) {
        const localPath = `${COVERS_PATH}${movieId}${ext}`;
        const url = `${GITHUB_BASE_URL}${movieId}${ext}`;
        
        try {
            let req = new Request();
            req.download(url, localPath);
            req = null; // Liberar memoria
            
            if (std.exists(localPath)) {
                console.log(`Descargado: ${movieId}${ext}`);
                return localPath;
            }
        } catch (e) {
            // Intentar con el siguiente formato
            continue;
        }
    }
    
    console.log(`No se encontró ${movieId} en PNG ni JPG`);
    return null;
}

function loadCoverImage(movieId) {
    // Si ya está en cache, retornar
    if (loadedCovers[movieId]) {
        return loadedCovers[movieId];
    }
    
    // Buscar con PNG o JPG
    const extensions = ['.png', '.jpg'];
    
    for (let ext of extensions) {
        const localPath = `${COVERS_PATH}${movieId}${ext}`;
        
        // Si existe localmente, cargar
        if (std.exists(localPath)) {
            try {
                const img = new Image(localPath);
                loadedCovers[movieId] = img;
                return img;
            } catch (e) {
                console.log(`Error cargando imagen ${movieId}${ext}: ${e}`);
            }
        }
    }
    
    return null;
}

function initCoversDirectory() {
    // Crear directorio de portadas si no existe
    if (!std.exists(COVERS_PATH)) {
        os.mkdir(COVERS_PATH);
        console.log("Directorio de portadas creado");
    }
}

//////////////////////////////////////////////////////////////////////////
///*                      Funciones de Dibujo                          *///
//////////////////////////////////////////////////////////////////////////

function drawHeader() {
    // Fondo del header
    Draw.rect(0, 0, screenWidth, headerHeight, colors.black);
    
    // Logo Netflix (más pequeño)
    font.scale = 1.0;
    font.color = colors.netflixRed;
    font.print(30, 35, "NETFLIX");
    
    // Menú de navegación (más compacto)
    let menuX = 180;
    
    for (let i = 0; i < menuItems.length; i++) {
        const isSelected = (i === selectedMenu);
        
        // Item seleccionado: más grande y blanco brillante
        if (isSelected) {
            font.scale = 0.8;
            font.color = colors.white;
        } else {
            font.scale = 0.7;
            font.color = colors.gray;
        }
        
        font.print(menuX, 40, menuItems[i]);
        menuX += 90; // Menos espacio entre items
    }
}

function drawCategory(category, categoryIndex, yPosition) {
    // Título de la categoría
    font.scale = 0.9;
    font.color = colors.white;
    font.print(30, yPosition, category.name);
    
    // Items de la categoría (horizontal con scroll)
    const itemsY = yPosition + 35;
    const startX = 30;
    const hScroll = horizontalScroll[categoryIndex];
    
    for (let i = 0; i < category.items.length; i++) {
        const item = category.items[i];
        const isSelected = (categoryIndex === currentCategory && i === currentItem);
        
        // Calcular posición X con scroll horizontal
        const itemX = startX + (i * (itemWidth + itemSpacing)) - hScroll;
        
        // Solo dibujar si está visible horizontalmente
        if (itemX + itemWidth > 0 && itemX < screenWidth) {
            // Intentar cargar imagen de portada
            const coverImg = loadCoverImage(item.id);
            
            if (coverImg) {
                // Dibujar imagen de portada
                coverImg.width = itemWidth;
                coverImg.height = itemHeight;
                coverImg.draw(itemX, itemsY);
            } else {
                // Fallback: rectángulo gris si no hay imagen
                const thumbColor = isSelected ? colors.white : colors.gray;
                Draw.rect(itemX, itemsY, itemWidth, itemHeight, thumbColor);
                
                // Título del item (solo si no hay imagen)
                font.scale = 0.6;
                font.color = isSelected ? colors.black : colors.white;
                font.print(itemX + 10, itemsY + itemHeight / 2, item.title);
            }
            
            // Borde si está seleccionado
            if (isSelected) {
                const borderWidth = 3;
                Draw.rect(itemX, itemsY, itemWidth, borderWidth, colors.netflixRed);
                Draw.rect(itemX, itemsY + itemHeight - borderWidth, itemWidth, borderWidth, colors.netflixRed);
                Draw.rect(itemX, itemsY, borderWidth, itemHeight, colors.netflixRed);
                Draw.rect(itemX + itemWidth - borderWidth, itemsY, borderWidth, itemHeight, colors.netflixRed);
            }
        }
    }
}

function drawCategories() {
    const startY = headerHeight + 30;
    const categorySpacing = 180; // Espacio entre categorías
    
    for (let i = 0; i < categories.length; i++) {
        const yPos = startY + (i * categorySpacing) - scrollOffset;
        
        // Solo dibujar si está visible
        if (yPos + categorySpacing > headerHeight && yPos < screenHeight) {
            drawCategory(categories[i], i, yPos);
        }
    }
}

function handleInput() {
    if (inputDelay > 0) {
        inputDelay--;
        return;
    }
    
    // Navegar con L1/R1 en el menú superior
    if (pad.justPressed(Pads.L1)) {
        if (selectedMenu > 0) {
            selectedMenu--;
            inputDelay = INPUT_COOLDOWN;
        }
    }
    else if (pad.justPressed(Pads.R1)) {
        if (selectedMenu < menuItems.length - 1) {
            selectedMenu++;
            inputDelay = INPUT_COOLDOWN;
        }
    }
    // Navegar con flechas en las categorías
    else if (pad.justPressed(Pads.LEFT)) {
        if (currentItem > 0) {
            currentItem--;
            
            // Ajustar scroll horizontal
            const itemX = 30 + (currentItem * (itemWidth + itemSpacing));
            const hScroll = horizontalScroll[currentCategory];
            if (itemX - hScroll < 30) {
                targetHorizontalScroll[currentCategory] = Math.max(0, itemX - 30);
            }
            
            inputDelay = INPUT_COOLDOWN;
        }
    }
    else if (pad.justPressed(Pads.RIGHT)) {
        const maxItems = categories[currentCategory].items.length - 1;
        if (currentItem < maxItems) {
            currentItem++;
            
            // Ajustar scroll horizontal
            const itemX = 30 + (currentItem * (itemWidth + itemSpacing));
            const itemRight = itemX + itemWidth;
            const hScroll = horizontalScroll[currentCategory];
            if (itemRight - hScroll > screenWidth - 30) {
                targetHorizontalScroll[currentCategory] = itemRight - screenWidth + 30;
            }
            
            inputDelay = INPUT_COOLDOWN;
        }
    }
    else if (pad.justPressed(Pads.UP)) {
        if (currentCategory > 0) {
            currentCategory--;
            currentItem = Math.min(currentItem, categories[currentCategory].items.length - 1);
            
            // Ajustar scroll suave
            const categoryY = headerHeight + 30 + (currentCategory * 180);
            if (categoryY - scrollOffset < headerHeight + 30) {
                targetScrollOffset = Math.max(0, categoryY - headerHeight - 30);
            }
            
            inputDelay = INPUT_COOLDOWN;
        }
    }
    else if (pad.justPressed(Pads.DOWN)) {
        if (currentCategory < categories.length - 1) {
            currentCategory++;
            currentItem = Math.min(currentItem, categories[currentCategory].items.length - 1);
            
            // Ajustar scroll suave
            const categoryY = headerHeight + 30 + (currentCategory * 180);
            const categoryBottom = categoryY + 180;
            if (categoryBottom - scrollOffset > screenHeight - 30) {
                targetScrollOffset = categoryBottom - screenHeight + 30;
            }
            
            inputDelay = INPUT_COOLDOWN;
        }
    }
    // Descargar portada con X
    else if (pad.justPressed(Pads.CROSS)) {
        const selectedMovie = categories[currentCategory].items[currentItem];
        console.log(`Descargando portada de: ${selectedMovie.title}`);
        
        // Si la red no está inicializada, intentar inicializarla ahora
        if (!NetInfo.Initialized) {
            console.log("Inicializando red automáticamente...");
            NetInit();
        }
        
        downloadCover(selectedMovie.id);
        inputDelay = INPUT_COOLDOWN;
    }
    // Salir con Triangle
    else if (pad.justPressed(Pads.TRIANGLE)) {
        std.exit(0);
    }
}

//////////////////////////////////////////////////////////////////////////
///*                      Inicialización                               *///
//////////////////////////////////////////////////////////////////////////

const pad = Pads.get(0);
const font = new Font("default");

// Cargar módulo de pads
IOP.loadDefaultModule(IOP.pads);

Screen.setVSync(true);
Screen.setFrameCounter(true);

// Inicializar sistema de portadas
initCoversDirectory();

// Solo verificar si la red ya está disponible (no inicializar)
try {
    const conf = Network.getConfig();
    if (conf && conf.ip && conf.ip !== "0.0.0.0") {
        NetInfo.Initialized = true;
        NetInfo.IP = conf.ip;
        console.log(`Red ya disponible: ${NetInfo.IP}`);
    } else {
        console.log("Red no disponible - se configurará al descargar");
    }
} catch (e) {
    console.log("Red no disponible - se configurará al descargar");
}

console.log("Netflix PS2 - Iniciado");

//////////////////////////////////////////////////////////////////////////
///*                      Loop Principal                               *///
//////////////////////////////////////////////////////////////////////////

while (true) {
    pad.update();
    Screen.clear();
    
    // Fondo
    Draw.rect(0, 0, screenWidth, screenHeight, colors.background);
    
    // Input
    handleInput();
    
    // Animación de scroll suave vertical
    if (Math.abs(targetScrollOffset - scrollOffset) > 1) {
        scrollOffset += (targetScrollOffset - scrollOffset) * 0.15;
    } else {
        scrollOffset = targetScrollOffset;
    }
    
    // Animación de scroll suave horizontal (para cada categoría)
    for (let i = 0; i < categories.length; i++) {
        if (Math.abs(targetHorizontalScroll[i] - horizontalScroll[i]) > 1) {
            horizontalScroll[i] += (targetHorizontalScroll[i] - horizontalScroll[i]) * 0.15;
        } else {
            horizontalScroll[i] = targetHorizontalScroll[i];
        }
    }
    
    // Dibujar categorías primero
    drawCategories();
    
    // Dibujar header al final (siempre encima)
    drawHeader();
    
    // Debug info
    font.scale = 0.6;
    font.color = colors.white;
    font.print(15, screenHeight - 60, `FPS: ${Screen.getFPS(360)}`);
    font.print(15, screenHeight - 45, `Menu: ${menuItems[selectedMenu]} | Cat: ${categories[currentCategory].name}`);
    font.print(15, screenHeight - 30, `Item: ${categories[currentCategory].items[currentItem].title}`);
    font.print(15, screenHeight - 15, `X: Descargar portada | Triangle: Salir`);
    
    Screen.flip();
}
