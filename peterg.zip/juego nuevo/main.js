const imagen1 = new Image("1.png"); // Sprite de la imagen 1  
const imagen2 = new Image("2.png"); // Sprite de la imagen 2
const imagen3 = new Image("3.png"); // Sprite de la imagen 3

let personajeX = 100; // Posición horizontal del personaje
let personajeY = 200; // Posición vertical inicial del personaje
const velocidad = 2; // Velocidad de movimiento
const velocidadSalto = 5; // Velocidad de salto
let enElAire = false; // Estado de si el personaje está en el aire
const limiteSuperior = 150; // Máxima altura de salto
const limiteInferior = 200; // Altura del suelo
let frame = 0; // Control de frames para alternar imágenes

while (true) {
    const pad = Pads.get(0); // Obtener el estado del controlador

    // Control de movimiento lateral
    if (pad.btns & Pads.LEFT) {
        personajeX -= velocidad; // Mover hacia la izquierda
    }
    if (pad.btns & Pads.RIGHT) {
        personajeX += velocidad; // Mover hacia la derecha
    }

    // Lógica de salto: solo permite saltar si no está en el aire
    if (pad.btns & Pads.CROSS && !enElAire) {
        personajeY -= velocidadSalto; // Saltar
        enElAire = true; // El personaje ahora está en el aire
    }

    // Verificar si el personaje está en el aire y manejar la caída
    if (enElAire) {
        // Caer
        if (personajeY < limiteInferior) {
            personajeY += velocidadSalto; // Mover hacia abajo
        }
        // Asegurarse de que el personaje no baje del suelo
        if (personajeY >= limiteInferior) {
            personajeY = limiteInferior; // Evitar que el personaje baje del suelo
            enElAire = false; // Ya no está en el aire
        }
    }

    // Alternar imagen
    frame = (frame + 1) % 20; // Controlar la velocidad del cambio de imagen
    const imagenActual = frame < 10 ? imagen1 : imagen2; // Alternar entre imagen1 e imagen2

    // Limpiar pantalla
    Screen.clear();

    // Dibujar la imagen 3 a pantalla completa
    imagen3.draw(0, 0); // Dibuja la imagen 3 en la esquina superior izquierda para que ocupe toda la pantalla

    // Dibujar el personaje
    imagenActual.draw(personajeX, personajeY); // Dibuja la imagen del personaje
    Screen.flip(); // Actualiza la pantalla
}
